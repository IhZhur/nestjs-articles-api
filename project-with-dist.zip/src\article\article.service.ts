/// START
import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Article } from './article.entity';
import { CreateArticleDto } from './dto/create-article.dto';
import { UpdateArticleDto } from './dto/update-article.dto';
import { User } from '../user/user.entity';

@Injectable()
export class ArticleService {
  constructor(
    @InjectRepository(Article)
    private readonly articleRepository: Repository<Article>,
  ) {}

  // --- Создание статьи с автором
  async create(dto: CreateArticleDto, user: User): Promise<Article> {
    const article = this.articleRepository.create({
      ...dto,
      author: user, // связь с автором
    });
    return await this.articleRepository.save(article);
  }

  // --- Получение всех статей (доработай фильтрацию и сортировку при необходимости)
  async findAll(query: any): Promise<Article[]> {
    // Фильтры, пагинация, published и т.д.
    // ...
    return this.articleRepository.find();
  }

  // --- Получение одной статьи
  async findOne(id: number): Promise<Article> {
    const article = await this.articleRepository.findOne({ where: { id } });
    if (!article) throw new NotFoundException('Статья не найдена');
    return article;
  }

  // --- Обновление статьи: только автор или админ
  async update(id: number, dto: UpdateArticleDto, user: User): Promise<Article> {
    const article = await this.articleRepository.findOne({ where: { id }, relations: ['author'] });
    if (!article) throw new NotFoundException('Статья не найдена');
    // --- Проверка: только автор или админ может обновлять
    if (article.author.id !== user.id && user.role !== 'admin') {
      throw new ForbiddenException('Вы не являетесь автором или админом');
    }
    Object.assign(article, dto);
    return this.articleRepository.save(article);
  }

  // --- Удаление статьи: только админ (дополнительно проверяется в контроллере через @Roles)
  async remove(id: number): Promise<void> {
    const article = await this.articleRepository.findOne({ where: { id } });
    if (!article) throw new NotFoundException('Статья не найдена');
    await this.articleRepository.delete(id);
  }
}
/// END
