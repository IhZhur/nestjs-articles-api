/// START
import {
  Controller,
  Get,
  Post,
  Body,
  Param,
  Put,
  Delete,
  ParseIntPipe,
  Query,
  UseGuards,
  Request, // 👈 для доступа к текущему пользователю
} from '@nestjs/common';
import { ArticleService } from './article.service';
import { CreateArticleDto } from './dto/create-article.dto';
import { UpdateArticleDto } from './dto/update-article.dto';
import { GetArticlesQueryDto } from './dto/get-articles-query.dto';
import { Article } from './article.entity';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

// 👇 Добавлено для RBAC
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/roles.decorator';
import { UserRole } from '../user/user.entity';

// Swagger-декораторы
import { ApiTags, ApiBearerAuth, ApiBody, ApiResponse } from '@nestjs/swagger';

@ApiTags('articles')
@ApiBearerAuth()
@Controller('articles')
// --- Подключаем Guards для RBAC и авторизации
@UseGuards(JwtAuthGuard, RolesGuard)
export class ArticleController {
  constructor(private readonly articleService: ArticleService) {}

  @ApiResponse({ status: 201, description: 'Создать статью.' })
  @ApiBody({ type: CreateArticleDto })
  // --- Разрешить создание статьи пользователям с ролью USER или ADMIN
  @Roles(UserRole.USER, UserRole.ADMIN)
  @Post()
  create(@Body() dto: CreateArticleDto, @Request() req): Promise<Article> {
    // Передаём пользователя для возможной связи с автором (реализовать при необходимости)
    return this.articleService.create(dto, req.user);
  }

  @ApiResponse({ status: 200, description: 'Получить список статей.' })
  // --- Чтение доступно всем авторизованным (можно не указывать @Roles)
  @Get()
  findAll(@Query() query: GetArticlesQueryDto): Promise<Article[]> {
    const parsedQuery = {
      page: query.page ? parseInt(query.page, 10) : 1,
      limit: query.limit ? parseInt(query.limit, 10) : 10,
      published:
        query.published !== undefined ? query.published === 'true' : undefined,
    };

    return this.articleService.findAll(parsedQuery);
  }

  @ApiResponse({ status: 200, description: 'Получить одну статью.' })
  @Get(':id')
  findOne(@Param('id', ParseIntPipe) id: number): Promise<Article> {
    return this.articleService.findOne(id);
  }

  @ApiResponse({ status: 200, description: 'Обновить статью.' })
  @ApiBody({ type: UpdateArticleDto })
  // --- Обновление разрешено USER и ADMIN (дальнейшая логика может ограничивать автора)
  @Roles(UserRole.USER, UserRole.ADMIN)
  @Put(':id')
  update(
    @Param('id', ParseIntPipe) id: number,
    @Body() dto: UpdateArticleDto,
    @Request() req,
  ): Promise<Article> {
    // Передаём пользователя в сервис для авторизации
    return this.articleService.update(id, dto, req.user);
  }

  @ApiResponse({ status: 200, description: 'Удалить статью.' })
  // --- Удалять может только ADMIN
  @Roles(UserRole.ADMIN)
  @Delete(':id')
  remove(@Param('id', ParseIntPipe) id: number): Promise<void> {
    return this.articleService.remove(id);
  }
}
/// END
