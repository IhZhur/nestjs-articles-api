import { MigrationInterface, QueryRunner } from "typeorm";

export class AddAuthorToArticle1750732688909 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<void> {
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
    }

}
