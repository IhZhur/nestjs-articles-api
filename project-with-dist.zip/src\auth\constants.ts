// src/auth/constants.ts
export const jwtConstants = {
  secret: 'supersecretkey', // ❗ в проде — использовать .env
};