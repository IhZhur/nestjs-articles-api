// typeorm.config.ts
import { AppDataSource } from './src/data-source';

export default AppDataSource;
