// Service
// src/user/user.service.ts
import { Injectable, BadRequestException } from '@nestjs/common'; // 👈 updated
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CreateUserDto, UserRole } from './dto/create-user.dto';
import { User } from './user.entity';

@Injectable()
export class UserService {
  constructor(
    @InjectRepository(User)
    private readonly userRepository: Repository<User>,
  ) {}

  async create(dto: CreateUserDto): Promise<User> {
    // Проверка на существующий email 👇
    const existing = await this.findByEmail(dto.email);
    if (existing) {
      throw new BadRequestException('User with this email already exists'); // 👈
    }

    const user = this.userRepository.create(dto);
    return this.userRepository.save(user);
  }

  async findAll(): Promise<User[]> {
    return this.userRepository.find();
  }

  async findByEmail(email: string): Promise<User | null> {
    return this.userRepository.findOne({ where: { email } });
  }
}
